package com.ninecmed.tablet.events;

public class ItnsUpdateAmpEvent {}
