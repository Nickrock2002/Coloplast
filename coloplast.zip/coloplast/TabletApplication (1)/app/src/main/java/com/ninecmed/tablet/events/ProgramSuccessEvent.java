package com.ninecmed.tablet.events;

public class ProgramSuccessEvent {}
